import Cropper from './js/cropper';

export default Cropper;
